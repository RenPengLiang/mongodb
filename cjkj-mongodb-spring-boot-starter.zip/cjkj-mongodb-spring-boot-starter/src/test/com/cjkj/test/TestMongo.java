package com.cjkj.test;

import com.cjkj.common.mongodb.Application;
import com.cjkj.common.mongodb.dao.MongoBaseDao;
import com.cjkj.test.entity.Student;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import java.time.LocalDate;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})// 指定启动类
public class TestMongo {

    @Autowired
    private MongoBaseDao mongoBaseDao;

    @Test
    public void testOne() {
        Student student = new Student();
        student.setId(1);
        student.setName("测试人名");
        student.setBathDate(LocalDate.now());
        mongoBaseDao.save(student);
    }

}
