package com.cjkj.test.entity;

import lombok.Data;

import java.time.LocalDate;

/**
 * 实体
 */
@Data
public class Student {

    private int id;

    private String name;

    private LocalDate bathDate;
}
